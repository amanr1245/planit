#imports
import turtle

'''FUNCTIONS----------------------------------------------------------------------------------------------------------------------------------------------
1. Set up the input trigger
2.Function that excutes what happens when trigger occurs'''
def MenuButton():
    screen.clear()
    screen.title("New Window!! :0")
    #Text
    turtle.ht()
    turtle.color('deep pink')
    style = ('Times New Roman', 30, 'italic')
    turtle.color('blue')
    turtle.penup()
    turtle.setposition(0,50)
    turtle.write('Enter Location!', font=style, align='center') 
    #style2 = ('Courier', 18, 'italic')
    '''turtle.setposition(0,-50)
    turtle.write('Click 1!', font=style2, align='center')''' 
    turtle.color('black')
    style3 = ('Courier', 26, 'italic')
    turtle.setposition(-10,-120)
    turtle.write('   1     2     3 !', font=style3, align='center') 
    screen.onkey(foodMenu,"1")
    screen.onkey(NatMenu,"2")
    screen.onkey(EntMenu,"3")
    screen.onkey(LIST,"i")
    turtle.pendown()
    
    #CIRCLE
    circ = turtle.Turtle()
    circ.hideturtle()
    
    #Circle #1
    circ.speed(0)
    circ.fillcolor('grey')
    circ.penup()
    circ.setposition(-120,-75)
    circ.pendown()
    circ.begin_fill()
    circ.color("black", "grey")
    circ.hideturtle()
    circ.circle(40) #Radius
    circ.end_fill()
    
    #Circle #2
    circ.fillcolor('grey')
    circ.penup()
    circ.setposition(0,-75)
    circ.pendown()
    circ.begin_fill()
    circ.color("black", "grey")
    circ.hideturtle()
    circ.circle(40) #Radius
    circ.end_fill()
    
    #Circle #3
    circ.fillcolor('grey')
    circ.penup()
    circ.setposition(120,-75)
    circ.pendown()
    circ.begin_fill()
    circ.color("black", "grey")
    circ.hideturtle()
    circ.circle(40) #Radius
    circ.end_fill()
    #-----------------------------------------------------------------------------------------------------------------------------
    
#FOOD WINDOW
def foodMenu():
    screen.clear()
    turtle.ht()
    screen.title('Food window!!')
    turtle.penup()
    turtle.setposition(0,290)
    style3 = ('Times New Roman', 20, 'bold')
    turtle.write('Food Near You...', font=style3, align='center') 
    turtle.hideturtle()
    screen.onkey(MenuButton,"Escape")
    turtle.pendown()
    
    #Drawing and Filling square
    circ = turtle.Turtle()
    circ.shape('turtle') #triangle anlso works
    circ.hideturtle()
    circ.color()
    ('black', 'black')
    circ.penup()
    circ.setposition(-180,50)
    circ.pendown()
    circ.color("grey")
    circ.speed(3)
    #fastest=0, fast=10, normal=6, slow=3, slowest=1
    circ.hideturtle()
    circ.begin_fill()#BEGIN FILLING
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.end_fill()  #END FILLING
    
    #Text
    turtle.penup()
    turtle.setposition(10,140)
    style4 = ('Times New Roman', 15, 'italic')
    turtle.write('Restaurant Title...', font=style4, align='center') 
    turtle.setposition(50,80)
    style5 = ('Times New Roman', 12, 'normal')
    text1  = '''Description-------------------------
    ----------------------------------
    ----------------------------------''' 
    turtle.write(text1, font=style5, align='center')
    turtle.hideturtle()
    turtle.penup()
    screen.onkey(SaveRes,"s")
    screen.onkey(LIST,"i")
    turtle.pendown()
    
    
def NatMenu():
    screen.clear()
    turtle.ht()
    screen.title('Nature Window!!')
    turtle.penup()
    turtle.setposition(0,290)
    style3 = ('Times New Roman', 20, 'bold')
    turtle.write('Adventure Near You...', font=style3, align='center') 
    turtle.hideturtle()
    screen.onkey(MenuButton,"Escape")
    turtle.pendown()
    
        #Drawing and Filling square
    circ = turtle.Turtle()
    circ.shape('turtle') #triangle anlso works
    circ.hideturtle()
    circ.color()
    ('black', 'black')
    circ.penup()
    circ.setposition(-180,50)
    circ.pendown()
    circ.color("grey")
    circ.speed(3)
    #fastest=0, fast=10, normal=6, slow=3, slowest=1
    circ.hideturtle()
    circ.begin_fill()#BEGIN FILLING
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    screen.onkey(LIST,"i")
    circ.end_fill()  #END FILLING
    
    #Text
    turtle.penup()
    turtle.setposition(10,140)
    style4 = ('Times New Roman', 15, 'italic')
    turtle.write('Adventure Title...', font=style4, align='center') 
    turtle.setposition(50,80)
    style5 = ('Times New Roman', 12, 'normal')
    text1  = '''Description-------------------------
    ----------------------------------
    ----------------------------------''' 
    turtle.write(text1, font=style5, align='center')
    turtle.hideturtle()
    turtle.pendown()
    
def EntMenu():
    screen.clear()
    turtle.ht()
    turtle.penup()
    turtle.setposition(0,290)
    style3 = ('Times New Roman', 20, 'bold')
    turtle.write('Entertainment Near You...', font=style3, align='center') 
    turtle.hideturtle()
    screen.onkey(MenuButton,"Escape")
    turtle.pendown()
    
    circ = turtle.Turtle()
    circ.shape('turtle') #triangle anlso works
    circ.hideturtle()
    circ.color()
    ('black', 'black')
    circ.penup()
    circ.setposition(-180,50)
    circ.pendown()
    circ.color("grey")
    circ.speed(3)
    #fastest=0, fast=10, normal=6, slow=3, slowest=1
    circ.hideturtle()
    circ.begin_fill()#BEGIN FILLING
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    circ.left(90)
    circ.fd(110)
    screen.onkey(LIST,"i")
    circ.end_fill()  #END FILLING
    
    #Text
    turtle.penup()
    turtle.setposition(25,140)
    style4 = ('Times New Roman', 15, 'italic')
    turtle.write('Entertainment Title...', font=style4, align='center') 
    turtle.setposition(50,80)
    style5 = ('Times New Roman', 12, 'normal')
    text1  = '''Description-------------------------
    ----------------------------------
    ----------------------------------''' 
    turtle.write(text1, font=style5, align='center')
    turtle.hideturtle()
    turtle.pendown()

res1=0 

def SaveRes():
    turtle.penup()
    turtle.color('green')
    turtle.setposition(90,140)
    style5 = ('Times New Roman', 10, 'bold')
    turtle.write('Saved', font=style5, align='center')
    turtle.hideturtle()
    turtle.pendown()
res1 = res1 + 1
    
def LIST():
    turtle.clear()
    screen.clear()
    turtle.penup()
    turtle.color('blue')
    turtle.setposition(-100,170)
    style5 = ('Times New Roman', 20, 'bold')
    turtle.write('Your List', font=style5, align='center')
    turtle.hideturtle()
    turtle.pendown()
    if res1==1:
        turtle.penup()
        turtle.color('green')
        turtle.setposition(-100,140)
        style5 = ('Times New Roman', 13, 'bold')
        turtle.write('Restaurant #1', font=style5, align='center')
        turtle.pendown()
        turtle.hideturtle()
    screen.onkey(MenuButton,"Escape")
#-----------------------------------------------------------------------------------------------------------------------------
    
'''-------------------------------------------------------------------------------------------------------------------------------------------------------'''


'''MAIN Window Setup------------------------------------------------------------------'''
# Create the main  screen
screen = turtle.Screen()
screen.title("PlanIt")

#Screen setup
t = turtle.Turtle()
screen.setup(410,700) #width x length
turtle.colormode(255)
screen.bgcolor(33, 26, 26)

#Welcome Text
t.color('white')
t.hideturtle()
style4 = ("Times New Roman", 26, "bold")
t.write('Welcome to PlanIt!', font=style4, align='center') 

#'Logo' Picture
NOTEPAD_IMAGE = "C:\\Users\\chill\\OneDrive\\Desktop\\UsedImagesCode\\notebook1.gif"
screen.register_shape(NOTEPAD_IMAGE)
tt = turtle.Turtle(shape=NOTEPAD_IMAGE)
tt.penup()
tt.goto(5,180)
tt.stamp()
'''--------------------------------------------------------------------------------------'''


'''MENU Window Screen--------------------------------------------------------------------'''
screen.onkey(MenuButton,"Return") #Press Enter to from MAIN to enter 

#Communcation
screen.listen()
turtle.mainloop()
turtle.done()